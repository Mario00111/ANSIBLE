This is the derby system directory which contains derby database and associated files.
The java property derby.system.home and environment variable DERBY_SYSTEM_HOME point to this location.
