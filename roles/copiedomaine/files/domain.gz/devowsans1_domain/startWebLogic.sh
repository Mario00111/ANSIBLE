#!/bin/sh

# WARNING: This file is created by the Configuration Wizard.
# Any changes to this script may be lost when adding extensions to this configuration.

DOMAIN_HOME="/u01/domains/devowsans1_domain"

${DOMAIN_HOME}/bin/startWebLogic.sh $*

