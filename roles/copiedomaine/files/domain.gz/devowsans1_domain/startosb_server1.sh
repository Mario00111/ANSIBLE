echo Demarrage du serveur osb_server1...
export JAVA_VENDOR=Oracle
export PRODUCTION_MODE=true
export USER_MEM_ARGS="-Xms1024m -Xmx1024m"
export PRE_CLASSPATH=.
./bin/startManagedWebLogic.sh osb_server1 devowsans1:7001 production
