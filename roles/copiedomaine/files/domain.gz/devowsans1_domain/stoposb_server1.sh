./bin/stopManagedWebLogic.sh osb_server1 devowsans1:7001
